# @enke/core

enke 跨平台分享核心。Web / 浏览器扩展 / Tauri 桌面 / iOS・Android 原生壳 / CLI 共用同一套
**归一化 → 创建分享 → 分片上传 → commit → 实时/离线队列** 逻辑。

- 协议唯一事实源：`@enke/protocol`（Zod → JSON Schema / Swift / Kotlin / C# / C）
- 运行时：现代浏览器、Node ≥ 22、Tauri WebView、React Native（需注入 `fetch`/`Blob`/`crypto`）
- 测试：`pnpm --filter @enke/core test`（20 个用例）、`pnpm --filter @enke/core typecheck`

## 安装 / 引入

```bash
# 已发布后
npm install @enke/core @enke/protocol zod
# 本仓库内开发（workspace 链接）
pnpm install
pnpm build:packages
```

```ts
import {
  EnkeShareClient,
  EnkeAuth,
  IndexedDbQueueStorage,
  LocalStorageQueueStorage,
  RealtimeClient,
  parseChatExport,
  prepareShare,
  truncateUtf8,
} from "@enke/core";
```

包现在导出构建后的 ESM + `.d.ts`（`dist/index.js` / `dist/index.d.ts`），可直接被 Vite、Node ESM、
旧扩展和旧 CLI 消费；发布前运行 `pnpm build:packages`，并用 `npm pack` 验证 tarball。
TypeScript 源码仍保留在 `src/`，测试直接引用源码。

## 快速开始

```ts
import { EnkeShareClient, EnkeAuth, IndexedDbQueueStorage } from "@enke/core";

const auth = new EnkeAuth({
  storage: new LocalStorageQueueStorage(localStorage, "enke-share:"),
  refreshUrl: "https://user.zenkee.com/api/v1/refresh",
});

const client = new EnkeShareClient({
  apiBase: "https://share.en.ke/v1",       // 自托管可改
  sharePageBase: "https://share.en.ke",
  platform: "web",
  appName: "enke Share",
  appVersion: "0.1.0",
  tokenProvider: () => auth.getAccessToken(),
  refreshTokenProvider: () => auth.refreshForClient(),
  queueStorage: new IndexedDbQueueStorage(), // 大文件离线队列
});

// 文本 / 链接 / 文件统一入口
const { share } = await client.send({
  title: "会议纪要",
  text: "……",
  url: "https://example.com",
  items: [
    { name: "photo.jpg", data: file, thumbnail: { mime: "image/jpeg", data: thumbBlob } },
    { name: "report.pdf", data: pdfFile },
  ],
  visibility: "link",          // link | password | private
  expiresIn: 7 * 24 * 3600,    // 秒；5 分钟–30 天
  password: "1234",            // visibility=password 时
  tags: ["work"],
});

console.log(share.shortUrl, share.id);
```

`send()` 内部：`prepareShare()`（限制/SHA-256/MIME/kind）→ `POST /v1/shares` → 并发分片 `PUT` → `POST /v1/shares/{id}/commit`。
失败默认自动入离线队列（`queueOnFailure: false` 可关）。

## 输入模型

```ts
interface ShareInput {
  kind?: "text" | "link" | "image" | "audio" | "video" | "file" | "chat" | "mixed"; // 可省略，自动推断
  title?: string;
  text?: string;                 // ≤16 KiB UTF-8，超长安全截断
  url?: string;                  // http/https ≤2048
  items?: FileInput[];           // ≤50 个；单个 ≤2 GiB
  chat?: ChatPayload;            // 聊天记录（见下）
  tags?: string[];               // ≤20
  visibility?: "link" | "password" | "private";
  expiresIn?: number;            // 秒
  password?: string;             // 4–128
  replyTo?: string;
  meta?: Record<string, string>;
  source?: Partial<ShareSource>;
  clientShareId?: string;        // 幂等键（UUID）
  createdAt?: number;
}

interface FileInput {
  name: string;
  mime?: string;                 // 缺省按扩展名推断
  data: Blob | ArrayBuffer | Uint8Array | UploadSource;
  width?: number;
  height?: number;
  durationMs?: number;
  caption?: string;
  text?: string;                 // OCR / 转写
  thumbnail?: {
    mime: "image/jpeg" | "image/png" | "image/webp";
    data: Blob | ArrayBuffer | Uint8Array | UploadSource;
    width?: number; height?: number;
  };
}
```

`UploadSource` 用于大文件流式读取（CLI / Tauri / 移动端）：

```ts
interface UploadSource {
  size: number;
  mime: string;
  name?: string;
  read(start: number, end: number): Promise<Uint8Array>; // [start, end)
}
```

## 主要 API

| 成员 | 说明 |
| --- | --- |
| `client.prepare(input)` | 仅归一化，返回 `{ envelope, files, warnings }`，可用于预览/入队 |
| `client.send(input, opts)` | 创建并上传，返回 `{ share, response }` |
| `client.sendPrepared(prepared, opts)` | 队列重放/自定义上传流程 |
| `client.queueShare(input)` | 归一化后仅入队，不联网 |
| `client.flushQueue()` | 重放队列（指数退避：1m/5m/15m/1h/6h） |
| `client.listQueue()` | 查看待发送项 |
| `client.getShare(id, { password })` | 读取分享（签名 URL 有时效） |
| `client.api.listShares({ limit, cursor })` | 当前用户分享列表 |
| `client.createRealtime(opts)` | 用户/设备实时客户端 |
| `client.createPairing(config)` | 设备配对（显示码 → 用户确认 → deviceToken） |
| `parseChatExport(input, provider?)` | 导入 WhatsApp/Telegram/Facebook/X/QQ/微信 导出 |

### 认证

`EnkeAuth` 复用 en.ke 现有 jwtsvr：

- `POST https://user.zenkee.com/api/v1/refresh`，body `{ refreshToken }`
- 响应 `{ data: { token, refreshToken } }`
- 提前 60s 刷新；`getAccessToken()` 供 `tokenProvider`，`refreshForClient()` 供 401 重试

设备模式使用 `DevicePairing.credentialProviders()` 生成 `deviceTokenProvider` / `deviceRefreshProvider`。

### 离线队列

`ShareQueue` 只依赖 `QueueStorage` 接口：

```ts
interface QueueStorage {
  get<T>(key: string): Promise<T | undefined>;
  set<T>(key: string, value: T): Promise<void>;
  delete(key: string): Promise<void>;
  keys(prefix?: string): Promise<string[]>;
}
```

内置 `MemoryQueueStorage`（测试）、`LocalStorageQueueStorage`（小数据）、`IndexedDbQueueStorage`（Blob/大文件）。
Node/CLI 请实现文件存储适配器；ESP32 不需要队列（固件只收通知）。

### 实时

```ts
import { RealtimeClient } from "@enke/core";

const rt = new RealtimeClient(client.api, {
  clientType: "user",
  handlers: {
    onEvent: (event) => console.log(event.type, event.shareId),
    onStatus: (status) => console.log(status), // idle/connecting/open/reconnecting/closed
    onError: (error) => console.warn(error),
  },
  autoAck: true,
});
await rt.start();
rt.stop();
```

流程：`POST /v1/rt/ticket` → `wss://share.en.ke/v1/rt?ticket=…` → 收事件 → 自动 `ack(seq,"shown")`；
25s 心跳、60s 无消息重连、指数退避、断线后带 `afterSeq` 补发（服务端 backlog 100）。
设备端收到的是扁平 `DeviceNotice`（文本按 UTF-8 字节截断、缩略图签名 URL），可直接渲染。

### 聊天导入

```ts
const { chat, warnings } = parseChatExport({ filename: "WhatsApp Chat with 小明.txt", content: text });
await client.send({ chat });
```

支持：WhatsApp `.txt`、Telegram `result.json`、Facebook `message.json`、X 归档（best-effort）、
QQ/微信文本导出（时间戳+发送者+内容）、通用 JSON 数组/CSV/纯文本。
解析失败会抛 `EnkeShareError("invalid_request")`，并保留 warnings。

能力边界（重要）：浏览器/移动沙箱**无法读取其他 App 私有数据库**。本模块只处理用户主动导出/分享的内容；
实时抓取微信/QQ 需平台辅助能力（Android 通知监听、桌面辅助功能），详见 `docs/chat-capture.md`。

## 错误处理

所有 API 错误抛 `EnkeShareError`：

```ts
try {
  await client.send(input);
} catch (e) {
  if (e instanceof EnkeShareError) {
    e.code;      // invalid_request | unauthorized | quota_exceeded | rate_limited | ...
    e.status;    // HTTP 状态
    e.retryable; // 是否可重试
    e.details;   // 例如 { queued: "true", shareId }
  }
}
```

重试建议：`retryable` 为 true 时按退避重试；`unauthorized` 走重新登录；`payload_too_large` 不要重试。

## 设计约束

- 协议字段 camelCase；时间戳毫秒（`DeviceNotice` 用秒）；无 null，可选字段省略。
- 文本截断一律 UTF-8 安全（`truncateUtf8`），不会产生 `�`。
- 文件 SHA-256 在客户端计算并 commit 校验；服务端仍会复核。
- 上传统一走 multipart 分片（小文件也是 part=1），缩略图单独 PUT。
- 不把 token/分享口令写入日志；`EnkeShareLogger` 由宿主注入。

## 目录

```
src/
  types.ts       公共类型（输入/配置/队列/实时/配对）
  normalize.ts   ShareInput → ShareEnvelopeV1 + 待上传文件
  api.ts         HTTP 客户端（重试/401 刷新/错误映射）
  upload.ts      分片上传 + 进度 + 重试
  queue.ts       离线队列 + 退避
  realtime.ts    WebSocket 客户端
  device.ts      设备配对
  auth.ts        jwtsvr token 刷新
  capture/       聊天导出解析
  storage/       localStorage / IndexedDB 适配
  text/mime/hash/ids/sources
tests/core.test.ts
```
