# @enke/core

enke 跨平台**发布**核心。Web / 浏览器扩展 / Tauri 桌面 / 原生壳 / CLI 共用同一套
**归一化 → 发布编排（docs/links/匿名）→ 离线队列 → 本地记录 / 登录后认领** 逻辑。

> 2026-10 合并版：分享不再单独存一份。文件/文本/聊天走 enkeworker `POST /api/v1/docs`，
> URL 走 `POST /api/v1/links`，匿名走 `/api/v1/anon/docs`、`/api/v1/anon/links` 并在登录后
> 用 `POST /api/v1/anon/bind` 认领。独立 Share Worker、分享页、分片上传、blobs、realtime ticket
> 全部删除（`upload.ts` / `realtime.ts` / `device.ts` 已移除）。

- 协议唯一事实源：`@enke/protocol`（Zod → JSON Schema / Swift / Kotlin / C# / C，wire 字段 snake_case）
- 运行时：现代浏览器、Node ≥ 22、Tauri WebView（需注入 `fetch`/`Blob`/`crypto`）
- 测试：`pnpm --filter @enke/core test`、`pnpm --filter @enke/core typecheck`

## 快速开始

```ts
import { EnkeShareClient, EnkeAuth, IndexedDbQueueStorage, LocalStorageQueueStorage } from "@enke/core";

const auth = new EnkeAuth({
  storage: new LocalStorageQueueStorage(localStorage, "enke-share:"),
  refreshUrl: "https://user.zenkee.com/api/v1/refresh",
});

const client = new EnkeShareClient({
  apiBase: "https://api.en.ke/api/v1",
  sharePageBase: "https://en.ke",        // 短链 https://en.ke/{slug}
  consoleBase: "https://www.en.ke",      // 记录页 https://www.en.ke/console/{docs,links}
  platform: "web",
  appName: "enke Share",
  appVersion: "0.2.0",
  tokenProvider: () => auth.getAccessToken(),
  refreshTokenProvider: () => auth.refreshForClient(),
});

// 发布（自动选择 /links、单文件 /docs、或 store-only zip + /docs）
const result = await client.send({
  title: "会议纪要",
  text: "……",
  items: [{ name: "photo.jpg", mime: "image/jpeg", data: file }],
  expiresIn: 7 * 24 * 3600,   // 秒；docs/links 按天存储，向上取整
  password: "1234",           // 仅登录可用；匿名接口拒绝 password
});

result.kind;      // "doc" | "link"
result.slug;      // 服务端 slug
result.shortUrl;  // https://en.ke/{slug}
result.expiresAt; // Unix 毫秒
result.anonymous; // 是否匿名发布
result.claimToken; // 仅匿名发布时存在，登录后 bindAnonymous() 用它认领
```

`send()` 内部：`prepareShare()`（限制/MIME/kind/保留期）→ `buildPublishPlan()`（决定发布方式与
metadata）→ `POST /docs` 或 `POST /links`（匿名走 `/anon/*`）→ 写本地记录。失败默认自动入离线队列
（`queueOnFailure: false` 可关）。

## 发布方式（spec §4.2）

| 输入 | 发布方式 | 接口 |
| --- | --- | --- |
| 只有 `url` | 短链 | `POST /links`（匿名 `POST /anon/links`） |
| 单个文件、无文本/URL/聊天，且 MIME 在 docs 白名单内 | 直传该文件 | `POST /docs`（匿名 `/anon/docs`） |
| 只有 `text` | `message-<YYYYMMDD-HHmmss>.md` | `POST /docs` |
| 其他（聊天/多文件/文本+文件/URL+文本/非白名单单文件） | store-only zip（文件 + `message.md`） | `POST /docs` |

`metadata` 映射：`comment = title`、`exp_days = clamp(ceil(expiresIn/86400), 1, plan.docMaxExpDays ?? 30)`、
`password`（仅登录且用户提供）。匿名上传不带 `exp_days` / `password`（服务端强制 24h）。

## 输入模型

```ts
interface ShareInput {
  title?: string;
  text?: string;                 // ≤16 KiB UTF-8，超长安全截断
  url?: string;                  // http/https ≤2048
  items?: FileInput[];           // ≤50；与 files 等价，可合并
  files?: FileInput[];
  chat?: ChatPayload;
  tags?: string[];               // 仅本地展示，不上送
  expiresIn?: number;            // 秒，默认 7 天，最小 1 天、最大 30 天（套餐可再收敛）
  password?: string;             // 4–128
}

interface FileInput {
  name: string;
  mime?: string;                 // 缺省按扩展名推断
  type?: "image" | "audio" | "video" | "file";
  data: Blob | ArrayBuffer | Uint8Array | UploadSource;
  width?: number; height?: number; durationMs?: number;
  caption?: string; text?: string; // OCR / 转写
}

interface UploadSource {         // Tauri/CLI 流式文件源
  size: number; mime: string; name?: string;
  read(start: number, end: number): Promise<Uint8Array>;
}
```

## 主要 API

| 成员 | 说明 |
| --- | --- |
| `client.send(input, opts)` | 发布，返回 `PublishResult`；`opts = { allowAnonymous?, queueOnFailure?, signal?, onProgress? }` |
| `client.prepare(input)` | 仅归一化，返回 `NormalizedShare`（预览/入队） |
| `client.sendPrepared(prepared, opts)` | 直接发布已归一化内容（队列重放） |
| `client.queueShare(input)` | 归一化后仅入队，不联网 |
| `client.flushQueue({ allowAnonymous? })` | 重放队列（指数退避：1m/5m/15m/1h/6h），返回 `FlushReport` |
| `client.listQueue()` / `client.queue.remove(id)` | 查看 / 删除待发布项 |
| `client.listLocalRecords()` | 本地记录（按创建时间倒序） |
| `client.listLocalRecordsForCurrentAccount()` | `{ subject, records }`：本账号 + 未认领匿名记录 |
| `client.bindAnonymous()` / `client.bindLocalRecords()` | 登录后分批（≤20）认领匿名分享，返回 `BindLocalReport` |
| `client.clearLocalRecords()` / `client.removeLocalRecord(kind, slug)` | 清空 / 删除单条本地记录 |
| `client.pairStart({ name?, platform? })` | 生成配对码，返回 `{ code, expiresAt }` |
| `client.listDevices()` | `DeviceInfo[]`（`id,name,platform,capabilities?,created_at,last_seen_at?`，ms） |
| `client.revokeDevice(id)` | 撤销设备 |
| `client.getPlanLimits()` | `/me` 的 `planLimits`（5 分钟缓存，可选能力，失败返回 null） |
| `client.getAccount()` | 完整 `/me`（plan / planName / usage / planLimits） |
| `client.api` | `EnkeApi`：`createDoc/createAnonDoc/createLink/createAnonLink/bindAnon/getMe/pairStart/pairClaim/listDevices/revokeDevice/health` |
| `parseChatExport(input, provider?)` | 导入 WhatsApp/Telegram/Facebook/X/QQ/微信 导出 |

### 本地记录（spec §4.2）

```ts
interface LocalShareRecord {
  slug: string;
  kind: "doc" | "link";
  title?: string;
  shortUrl: string;
  createdAt: number;   // ms
  expiresAt: number;   // ms
  anonymous: boolean;
  claimToken?: string; // 仅匿名未认领时存在
  claimState: "unbound" | "bound" | "failed";
  boundAt?: number;    // ms
  consoleUrl: string;  // https://www.en.ke/console/{docs,links}
}
```

账号分区（`scope`）与认领重试字段（`claimAttempts` / `lastClaimAttemptAt` / `lastClaimError`）为内部字段：
绑定成功后 `claimToken` 立即清除、记录迁移到当前账号；失败按 5m→1h 指数退避，避免请求风暴。

### 离线队列

`ShareQueue` 只依赖 `QueueStorage` 接口（`get/set/delete/keys`）。内置 `MemoryQueueStorage`、
`LocalStorageQueueStorage`、`IndexedDbQueueStorage`。`QueuedShare` 是扁平结构（`kind/title/text?/url?/chat?/files[]`），
不含旧 share envelope。

### 认证

`EnkeAuth` 复用 en.ke 现有 jwtsvr：`POST /api/v1/refresh` body `{ refreshToken }` → `{ data: { token, refreshToken } }`；
提前 60s 刷新，`getAccessToken()` 供 `tokenProvider`，`refreshForClient()` 供 401 重试。
设备页使用用户 JWT（不再有 device token / 轮询配对）。

## 错误处理

所有 API 错误抛 `EnkeShareError`：

```ts
try {
  await client.send(input, { allowAnonymous: true });
} catch (e) {
  if (e instanceof EnkeShareError) {
    e.code;       // 服务端错误码原样透传（如 ANON_QUOTA_EXCEEDED）；无 JSON 错误体时按状态归一（401 → AUTH_REQUIRED）
    e.serverCode; // 服务端原始错误码（若有）
    e.status;     // HTTP 状态
    e.retryable;  // 429 / 5xx / rate_limited 等
    e.details;    // 服务端 params（如 { limit: "5", current: "5" }）；入队时含 { queued: "true" }
  }
}
```

## 设计约束

- wire 字段 snake_case（DocShare/LinkRecord/Bind*/DeviceNotice…）；本地 TS 类型（`PublishResult`）camelCase。
- 时间戳：`DocShare.ctime/mtime`、`LinkRecord.ctime/mtime` 为 Unix 秒；设备/通知/本地记录为 Unix 毫秒。
- 文本截断一律 UTF-8 安全（`truncateUtf8`）；zip 为 store-only（无压缩，CRC32 正确）。
- 不把 token / claimToken 写入日志；`EnkeShareLogger` 由宿主注入。
- 客户端不再计算 SHA-256、不再分片、不再有实时通道。

## 目录

```
src/
  types.ts       公共类型（输入/配置/队列/记录/发布结果）
  normalize.ts   ShareInput → NormalizedShare
  publish.ts     发布方式决策 + metadata/文件名 + zip 打包 + Markdown
  api.ts         EnkeApi（docs/links/anon/bind/me/devices，错误映射）
  client.ts      EnkeShareClient（发布/队列/记录/认领/设备）
  queue.ts       离线队列 + 退避
  records.ts     本地记录 + 认领状态机
  auth.ts        jwtsvr token 刷新
  capture/       聊天导出解析
  zip.ts         store-only ZIP
  storage/       localStorage / IndexedDB 适配
  text/mime/hash/ids/sources
tests/           核心/发布映射/记录/设备/zip
```
