# @enke/protocol

enke Share 协议的唯一事实来源（2026-10 docs/links 合并版）。

- `src/schemas.ts` — Zod schema、枚举、限制（**wire 字段一律 snake_case**）
- `src/limits.ts` — 客户端/服务端/ESP32 共同遵守的常量
- `scripts/gen.ts` — 生成 JSON Schema 与 TS / Swift / Kotlin / C# / C 模型
- `scripts/vectors.ts` — 生成跨语言测试向量（JSON，无 CBOR：实时通道已删除）
- `generated/` — **自动生成，禁止手改**

```bash
pnpm --filter @enke/protocol codegen   # 生成模型
pnpm --filter @enke/protocol vectors   # 生成测试向量
pnpm --filter @enke/protocol build     # 构建 dist/index.js + d.ts（可发布）
pnpm --filter @enke/protocol test      # 校验向量
```

npm 包导出 `dist/index.js`（ESM）与 `dist/index.d.ts`；`generated/schema.json` 也随包发布，
供服务端/其他语言做运行时校验。发布前用 `npm pack --dry-run` 确认 tarball 内容。

## 契约范围

保留（聊天/来源/限制/错误）：`Platform`、`ShareKind`、`ItemType`、`ChatProvider`、`CaptureMethod`、
`ConversationType`、`MessageType`、`ChatConversation`、`ChatMessage`、`ChatPayload`、`ShareSource`、
`NoticeType`、`AckStatus`、`PairStatus`、`ErrorCode`、`ApiError`、`limits`。

新增（enkeworker）：

| 模型 | 说明 |
| --- | --- |
| `DocShare` | `POST /docs` 返回的文档记录；`ctime/mtime` 为 **Unix 秒** |
| `DocCreateResponse` | `{success, result:{doc}}` |
| `AnonDocCreateResponse` | `{success, result:{doc, claim_token}}`（`/anon/docs`） |
| `LinkRecord` | `POST /links` 返回的短链记录；`ctime/mtime` 为 Unix 秒 |
| `LinkCreateResponse` | `{success, link, claim_token?}` |
| `AnonLinkCreateResponse` | `{success, link, claim_token}`（`/anon/links`，token 在顶层） |
| `BindItem` / `BindRequest` / `BoundItem` / `FailedItem` / `BindResponse` | `POST /anon/bind`（单次 ≤20） |
| `DeviceInfo` | `{id,name,platform,capabilities?,created_at,last_seen_at?}`，**毫秒** |
| `PairStartRequest` / `PairStartResult` / `PairStartResponse` | 用户侧生成配对码 |
| `PairClaimRequest` / `PairClaimResult` / `PairClaimResponse` | 设备侧认领配对码 |
| `DeviceListResponse` / `DeviceNoticeListResponse` | 设备与通知列表 |
| `DeviceNotice` | 设备通知投影（`created_at/expires_at` 为毫秒） |
| `NoticeAck` | `{status}`，`AckStatus = shown｜stored｜error｜skip` |
| `HealthResponse` | `{ok:true, service:"enkeworker", v:1}` |
| `MeResponse` / `PlanLimits` / `PlanUsage` | `/me` 的客户端子集（plan/planName/usage/planLimits） |

已删除：`ShareEnvelopeV1`、`ShareRecordV1`、`ShareItemRecord`、`UploadItemPlan`、`CreateShareResponseV1`、
`Commit*`、`UploadPart*`、`BindShares*`、`RealtimeTicket*`、`RealtimeEventV1`、`NoticePoll*`、旧 `Pair*`、
`Visibility`、`ShareStatus`、`ItemStatus`、`RealtimeFormat`、`RealtimeType`、`ClientType`、`BindShareStatus`。

## 原生端用法

| 端 | 文件 |
|---|---|
| iOS / macOS | `generated/swift/ShareModels.swift` |
| Android | `generated/kotlin/ShareModels.kt`（需要 kotlinx.serialization，`ignoreUnknownKeys = true`） |
| Windows | `generated/csharp/ShareModels.cs`（System.Text.Json） |
| ESP32 | `generated/c/share_models.h` + `platforms/esp32/components/share_proto` |
| TypeScript | `generated/ts/models.ts` 或直接 `z.infer` |

生成物属性名 = wire 名（snake_case），`gen.ts` 不做 camelCase 转换。响应模型非 strict（服务端新增字段不破坏兼容），
请求模型 `BindRequest` / `NoticeAck` / `PairStartRequest` / `PairClaimRequest` 为 strict。

修改协议必须同时更新：
1. `src/schemas.ts`
2. 本文档与 `docs/protocol.md`
3. 重新生成并跑 `pnpm test`
4. 若破坏兼容，升 `PROTOCOL_VERSION` 并在 `docs/protocol.md` 记录迁移
