# @enke/protocol

enke Share 协议的唯一事实来源。

- `src/schemas.ts` — Zod schema、枚举、限制
- `scripts/gen.ts` — 生成 JSON Schema 与 TS / Swift / Kotlin / C# / C 模型
- `scripts/vectors.ts` — 生成跨语言测试向量（JSON + CBOR）
- `generated/` — **自动生成，禁止手改**

```bash
pnpm --filter @enke/protocol codegen   # 生成模型
pnpm --filter @enke/protocol vectors   # 生成测试向量
pnpm --filter @enke/protocol build     # 构建 dist/index.js + d.ts（可发布）
pnpm --filter @enke/protocol test      # 校验向量
```

npm 包导出 `dist/index.js`（ESM）与 `dist/index.d.ts`；`generated/schema.json` 也随包发布，
供服务端/其他语言做运行时校验。发布前用 `npm pack --dry-run` 确认 tarball 内容。

原生端用法：

| 端 | 文件 |
|---|---|
| iOS / macOS | `generated/swift/ShareModels.swift` |
| Android | `generated/kotlin/ShareModels.kt`（需要 kotlinx.serialization） |
| Windows | `generated/csharp/ShareModels.cs`（System.Text.Json） |
| ESP32 | `generated/c/share_models.h` + `platforms/esp32/components/share_proto` |
| TypeScript | `generated/ts/models.ts` 或直接 `z.infer` |

修改协议必须同时更新：
1. `src/schemas.ts`
2. 本文档与 `docs/protocol.md`
3. 重新生成并跑 `pnpm test`
4. 若破坏兼容，升 `PROTOCOL_VERSION` 并在 `docs/protocol.md` 记录迁移
